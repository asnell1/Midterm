
function initMap() {
   var map = new google.maps.Map(document.getElementById('map'), {
    zoom: 4,
    center: {lat: 35, lng: -90}
  });


var ctaLayer = new google.maps.KmlLayer({
    url: 'https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=2&ved=0ahUKEwi3tdPCt8TLAhVFQSYKHZAbBmkQFggjMAE&url=http%3A%2F%2Fedna.usgs.gov%2Fwatersheds%2Fsheds%2FUSWatersheds%2FUSWatersheds.kml&usg=AFQjCNENSziUhGztVAZSedpTFCH5WeYfLw&sig2=gSchjGRVVnO9LmPr8gU36w&bvm=bv.116954456,d.eWE',
    map: map,
preserveViewport: true});
}