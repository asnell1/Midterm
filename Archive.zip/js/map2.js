var map;  
      require([  
        "esri/map", 
        "esri/dijit/Scalebar", 
        "esri/layers/ArcGISDynamicMapServiceLayer",  
        "esri/dijit/BasemapToggle", 
        "dojo/domReady!",   
      ], function(  
        Map, 
        Scalebar, ArcGISDynamicMapServiceLayer, BasemapToggle 
      ) {  
        
        map = new Map("map", {  
          basemap: "streets",  
          center: [-120, 37.5],  
          zoom: 6  
        
        }); 
					
       var toggle = new BasemapToggle({
        map: map,
        basemap: "satellite"
        }, "BasemapToggle");
        toggle.startup();

		var popdensity = new ArcGISDynamicMapServiceLayer("http://services.gis.ca.gov/arcgis/rest/services/Society/Population_Density/MapServer", 
		{"opacity": 0.5 });
        
        var unemploymentandpoverty = new ArcGISDynamicMapServiceLayer("http://services.gis.ca.gov/arcgis/rest/services/Demographics/UnemploymentAndPoverty/MapServer");
        
        map.addLayer(unemploymentandpoverty);
        map.addLayer(popdensity);
  
        var scalebar = new Scalebar({  
          map: map,  
          scalebarUnit: "dual"  
        });  
          
      }); 
